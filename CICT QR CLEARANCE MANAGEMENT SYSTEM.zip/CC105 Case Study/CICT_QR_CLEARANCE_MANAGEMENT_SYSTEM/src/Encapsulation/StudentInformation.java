/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Encapsulation;

/**
 *
 * @author Dan
 */
public class StudentInformation {
    String id,name,year,section,Tech,Charter,Umeet,Stats;
    
    public StudentInformation(String id, String name, String year, String section, String Tech, String Charter, String Umeet, String Stats){
        this.id = id;
        this.name = name;
        this.year = year;
        this.section = section;
        this.Tech = Tech;
        this.Charter = Charter;
        this.Umeet = Umeet;
        this.Stats = Stats;
    }
    
    public StudentInformation(String Tech, String Charter, String Umeet){
        this.Tech = Tech;
        this.Charter = Charter;
        this.Umeet = Umeet;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getTech() {
        return Tech;
    }

    public void setTech(String Tech) {
        this.Tech = Tech;
    }
    
    public String getCharter() {
        return Charter;
    }

    public void setCharter(String Charter) {
        this.Charter = Charter;
    }

    public String getUmeet() {
        return Umeet;
    }

    public void setUmeet(String Umeet) {
        this.Umeet = Umeet;
    }

    public String getStats() {
        return Stats;
    }

    public void setStats(String Stats) {
        this.Stats = Stats;
    }
}
