/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Encapsulation;

/**
 *
 * @author Dan
 */
public class EncapsulateValue {
    
    private static EncapsulateValue instance = new EncapsulateValue();
    private String user;
    private String id;
    private String nickname;
    private String StudName;
    
    private String FirstName;
    private String MiddleName;
    private String LastName;
    
    private String StudId;
    private String StudYearLevel;
    private String StudSection;
    
    private String Tech;
    private String Charter;
    private String Umeet;
    
    private int T_Amount;
    private int T_Goal;
    private int C_Amount;
    private int C_Goal;
    private int U_Amount;
    private int U_Goal;
    
    private int TechAmount;
    private int CharterAmount;
    private int UmeetAmount;
    
    private EncapsulateValue(){
    }
    
    public EncapsulateValue(int TechAmount, int CharterAmount, int UmeetAmount){
        this.TechAmount = TechAmount;
        this.CharterAmount = CharterAmount;
        this.UmeetAmount = UmeetAmount;
    }
    
    public EncapsulateValue(int T_Amount, int T_Goal, int C_Amount, int C_Goal, int U_Amount, int U_Goal){
        this.T_Amount = T_Amount;
        this.T_Goal = T_Goal;
        this.C_Amount = C_Amount;
        this.C_Goal = C_Goal;
        this.U_Amount = U_Amount;
        this.U_Goal = U_Goal;
    }
    
    public static EncapsulateValue getInstance(){
        return instance;
    }
 
    public void setUser(String user){
        this.user = user;
    }
    
    public String getUser(){
        return user;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getId() {
        return id;
    }
    
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
    
    public String getNickname() {
        return nickname;
    }
    
    public void setStudName(String StudName) {
        this.StudName = StudName;
    }
    
    public String getStudName() {
        return StudName;
    }

    public void setStudId(String StudId) {
        this.StudId = StudId;
    }
    
    public String getStudId() {
        return StudId;
    }
    
    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getMiddleName() {
        return MiddleName;
    }

    public void setMiddleName(String MiddleName) {
        this.MiddleName = MiddleName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getStudYearLevel() {
        return StudYearLevel;
    }

    public void setStudYearLevel(String StudYearLevel) {
        this.StudYearLevel = StudYearLevel;
    }

    public String getStudSection() {
        return StudSection;
    }

    public void setStudSection(String StudSection) {
        this.StudSection = StudSection;
    }
    
    public String getTech() {
        return Tech;
    }

    public void setTech(String Tech) {
        this.Tech = Tech;
    }

    public String getCharter() {
        return Charter;
    }

    public void setCharter(String Charter) {
        this.Charter = Charter;
    }

    public String getUmeet() {
        return Umeet;
    }

    public void setUmeet(String Umeet) {
        this.Umeet = Umeet;
    }

    public int getT_Amount() {
        return T_Amount;
    }

    public void setT_Amount(int T_Amount) {
        this.T_Amount = T_Amount;
    }

    public int getT_Goal() {
        return T_Goal;
    }

    public void setT_Goal(int T_Goal) {
        this.T_Goal = T_Goal;
    }

    public int getC_Amount() {
        return C_Amount;
    }

    public void setC_Amount(int C_Amount) {
        this.C_Amount = C_Amount;
    }

    public int getC_Goal() {
        return C_Goal;
    }

    public void setC_Goal(int C_Goal) {
        this.C_Goal = C_Goal;
    }

    public int getU_Amount() {
        return U_Amount;
    }

    public void setU_Amount(int U_Amount) {
        this.U_Amount = U_Amount;
    }

    public int getU_Goal() {
        return U_Goal;
    }

    public void setU_Goal(int U_Goal) {
        this.U_Goal = U_Goal;
    }

    
    
    
}
