package Controller;

import java.sql.*;
import java.io.IOException;
import java.net.URL;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javax.swing.JOptionPane;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import MainClass.Start;

public class ClearList_UIController implements Initializable {

    Connection conn;
    PreparedStatement pst;
    ResultSet rs;

    @FXML
    private BorderPane BDP_background;
    @FXML
    private Pane PANE_container;
    @FXML
    private Button BTN_clear;
    @FXML
    private Button BTN_cancel;
    @FXML
    private GridPane GRID_container;
    @FXML
    private Text TXT_clearConfirm;
    @FXML
    private Circle SHAPE_circle;
    @FXML
    private ImageView IMG_clearIcon;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void BTN_clear(ActionEvent event) throws IOException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance","root","");
        } catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        try {
            pst = conn.prepareStatement("TRUNCATE TABLE tblstudents");
            pst.executeUpdate();

            JOptionPane.showMessageDialog(null, "List Cleared Successfully!");
            JOptionPane.showMessageDialog(null, "You will be directed to the Dashboard!");

            Parent Dashboard = FXMLLoader.load(getClass().getResource("/FXML/Dashboard_Admin_UI.fxml"));
            Scene ShowDashboard = new Scene(Dashboard);
            Stage appStage = (Stage) ((Node)event.getSource()).getScene().getWindow();
            appStage.setScene(ShowDashboard);
            appStage.setMaximized(false);
            appStage.setMaximized(true);
            appStage.show();
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void BTN_cancel(ActionEvent event) throws IOException {
        Parent Cancel = FXMLLoader.load(getClass().getResource("/FXML/Dashboard_Admin_UI.fxml"));
        Scene Back = new Scene(Cancel);
        Stage appStage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        appStage.setScene(Back);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
        
    }

}
