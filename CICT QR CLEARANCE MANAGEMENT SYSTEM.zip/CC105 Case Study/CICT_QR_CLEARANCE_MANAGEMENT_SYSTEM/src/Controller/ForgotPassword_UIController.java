package Controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

import Encapsulation.EncapsulateValue;
import MainClass.Start;

public class ForgotPassword_UIController implements Initializable {

    Connection conn;
    PreparedStatement pst;
    ResultSet rs;

    EncapsulateValue EV = EncapsulateValue.getInstance();

    @FXML
    private BorderPane BDP_background;
    @FXML
    private Pane PANE_container;
    @FXML
    private Text TXT_title;
    @FXML
    private TextField TXTF_email;
    @FXML
    private TextField TXTF_idNumber;
    @FXML
    private Button BTN_continue;
    @FXML
    private Pane PANE_iconBG1;
    @FXML
    private ImageView IMAGE_email;
    @FXML
    private Pane PANE_iconBG2;
    @FXML
    private ImageView IMAGE_idNumber;
    @FXML
    private Button BTN_back;
    @FXML
    private ImageView IMAGE_back;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //TODO
    }

    @FXML
    private void BTN_continue(ActionEvent event) throws IOException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance", "root", "");
        } catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        String user = TXTF_email.getText();
        EV.setUser(user);
        String id = TXTF_idNumber.getText();
        EV.setId(id);
        int y = 0;
        try {
            pst = conn.prepareStatement("SELECT * FROM tbluseraccount");
            rs = pst.executeQuery();

            while (rs.next()) {
                String email = rs.getString("USR_EADDRESS");
                String uid = rs.getString("ID_NUM");

                if (user.equals(email) && id.equals(uid)) {
                    JOptionPane.showMessageDialog(null, "Email and ID Number Match!");
                    Parent ResetPass = FXMLLoader.load(getClass().getResource("/FXML/ResetPassword_UI.fxml"));
                    Scene GoResetPass = new Scene(ResetPass);
                    Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    appStage.setScene(GoResetPass);
                    appStage.setMaximized(false);
                    appStage.setMaximized(true);
                    appStage.show();
                    y++;
                    break;
                }
            }
            if (y == 0) {
                JOptionPane.showMessageDialog(null, "Email and ID Number Doesn't Match!");
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void BTN_back(ActionEvent event) throws IOException {
        Parent Back = FXMLLoader.load(getClass().getResource("/FXML/Login_UI.fxml"));
        Scene GoLogin = new Scene(Back);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(GoLogin);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
        
    }

}
