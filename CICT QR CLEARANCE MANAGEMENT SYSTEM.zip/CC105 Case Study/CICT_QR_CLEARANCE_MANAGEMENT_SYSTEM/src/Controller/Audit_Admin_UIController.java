package Controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javax.swing.JOptionPane;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.print.PageLayout;
import javafx.print.PageOrientation;
import javafx.print.Paper;
import javafx.print.Printer;
import javafx.print.PrinterJob;
import javafx.scene.control.Tab;
import javafx.scene.layout.AnchorPane;
import javafx.scene.transform.Scale;

import Encapsulation.EncapsulateValue;
import Encapsulation.StudentInformation;
import MainClass.Start;

public class Audit_Admin_UIController implements Initializable {

    Connection conn;
    PreparedStatement pst;
    ResultSet rs;

    EncapsulateValue EV = EncapsulateValue.getInstance();
    ObservableList<EncapsulateValue> AuditList = FXCollections.observableArrayList();
    ObservableList<StudentInformation> Students = FXCollections.observableArrayList();
    
    @FXML
    private BorderPane BDP_background;
    @FXML
    private Pane PANE_containerBlue;
    @FXML
    private Pane PANE_white;
    @FXML
    private Text TXT_title1;
    @FXML
    private Text TXT_title11;
    @FXML
    private Text TXT_title111;
    @FXML
    private Text TXT_title1111;
    @FXML
    private TextField TXTF_TAmount;
    @FXML
    private TextField TXTF_TGoal;
    @FXML
    private Text TXT_title112;
    @FXML
    private Text TXT_title1121;
    @FXML
    private Text TXT_title11111;
    @FXML
    private TextField TXTF_CAmount;
    @FXML
    private TextField TXTF_CGoal;
    @FXML
    private Text TXT_title11211;
    @FXML
    private Text TXT_title111111;
    @FXML
    private TextField TXTF_UAmount;
    @FXML
    private TextField TXTF_UGoal;
    @FXML
    private Button BTN_generate;
    @FXML
    private Button BTN_cancel;
    @FXML
    private Text TXT_title;
    @FXML
    private Circle SHAPE_circle;
    @FXML
    private ImageView IMAGE_add;
    @FXML
    private Button BTN_setvalue;
    @FXML
    private Text TXT_TSpay;
    @FXML
    private Text TXT_TTotal;
    @FXML
    private Text TXT_CSpay;
    @FXML
    private Text TXT_CTotal;
    @FXML
    private Text TXT_USpay;
    @FXML
    private Text TXT_UTotal;
    @FXML
    private Tab TAB_Techno;
    @FXML
    private AnchorPane APANE_Techno;
    @FXML
    private AnchorPane APANE_Charter;
    @FXML
    private AnchorPane APANE_Umeet;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance", "root", "");
        } catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        try {
            pst = conn.prepareStatement("SELECT SUM(CASE WHEN TechnoD != 'Unpaid' THEN TechnoD ELSE 0 END) AS TechnoSum, " + "SUM(CASE WHEN CharterD != 'Unpaid' THEN CharterD ELSE 0 END) AS CharterSum, " + "SUM(CASE WHEN UmeetD != 'Unpaid' THEN UmeetD ELSE 0 END) AS UmeetSum, " + "COUNT(CASE WHEN TechnoD != 'Unpaid' THEN 1 END) AS TechnoCount, " + "COUNT(CASE WHEN CharterD != 'Unpaid' THEN 1 END) AS CharterCount, " + "COUNT(CASE WHEN UmeetD != 'Unpaid' THEN 1 END) AS UmeetCount " + "FROM tblstudents");
            rs = pst.executeQuery();

            while (rs.next()) {
                int technoSum = rs.getInt("TechnoSum");
                int charterSum = rs.getInt("CharterSum");
                int umeetSum = rs.getInt("UmeetSum");

                int technoCount = rs.getInt("TechnoCount");
                int charterCount = rs.getInt("CharterCount");
                int umeetCount = rs.getInt("UmeetCount");

                TXT_TTotal.setText(Integer.toString(technoSum));
                TXT_CTotal.setText(Integer.toString(charterSum));
                TXT_UTotal.setText(Integer.toString(umeetSum));

                TXT_TSpay.setText(Integer.toString(technoCount));
                TXT_CSpay.setText(Integer.toString(charterCount));
                TXT_USpay.setText(Integer.toString(umeetCount));
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        try {
            pst = conn.prepareStatement("SELECT * FROM tblauditing");
            rs = pst.executeQuery();

            if (rs.next()) {
                EncapsulateValue value = new EncapsulateValue(rs.getInt("Techno_Amount"), rs.getInt("Techno_Goal"), rs.getInt("Charter_Amount"), rs.getInt("Charter_Goal"), rs.getInt("Umeet_Amount"), rs.getInt("Umeet_Goal"));
                AuditList.add(value);

                TXTF_TAmount.setText(String.valueOf(value.getT_Amount()));
                TXTF_TGoal.setText(String.valueOf(value.getT_Goal()));
                TXTF_CAmount.setText(String.valueOf(value.getC_Amount()));
                TXTF_CGoal.setText(String.valueOf(value.getC_Goal()));
                TXTF_UAmount.setText(String.valueOf(value.getU_Amount()));
                TXTF_UGoal.setText(String.valueOf(value.getU_Goal()));
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void BTN_generate(ActionEvent event) {
        Pane printPane = new Pane();
        printPane.getChildren().addAll(APANE_Techno, APANE_Charter, APANE_Umeet);

        APANE_Techno.setLayoutX(215);
        APANE_Techno.setLayoutY(50);

        APANE_Charter.setLayoutX(215);
        APANE_Charter.setLayoutY(350);

        APANE_Umeet.setLayoutX(215);
        APANE_Umeet.setLayoutY(650);

        printPane.setPrefWidth(1000);
        printPane.setPrefHeight(1800);

        Printer printer = Printer.getDefaultPrinter();
        PageLayout pageLayout = printer.createPageLayout(Paper.A4, PageOrientation.PORTRAIT, 0, 0, 0, 0);
        PrinterJob job = PrinterJob.createPrinterJob(printer);

        if (job != null) {
            job.getJobSettings().setPageLayout(pageLayout);

            boolean showDialog = job.showPageSetupDialog(null);
            if (showDialog) {
                double scaleX = pageLayout.getPrintableWidth() / printPane.getPrefWidth();
                double scaleY = pageLayout.getPrintableHeight() / printPane.getPrefHeight();
                printPane.getTransforms().add(new Scale(scaleX, scaleY));

                boolean success = job.printPage(printPane);
                if (success) {
                    JOptionPane.showMessageDialog(null, "Print Success!");
                    job.endJob();
                } else {
                    JOptionPane.showMessageDialog(null, "Print Canceled!");
                }
            }
        }

    }

    @FXML
    private void BTN_cancel(ActionEvent event) throws IOException {
        Parent Cancel = FXMLLoader.load(getClass().getResource("/FXML/Dashboard_Admin_UI.fxml"));
        Scene Back = new Scene(Cancel);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(Back);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
        
    }

    @FXML
    private void BTN_setvalue(ActionEvent event) {
        int tAmount = Integer.parseInt(TXTF_TAmount.getText());
        int tGoal = Integer.parseInt(TXTF_TGoal.getText());
        int cAmount = Integer.parseInt(TXTF_CAmount.getText());
        int cGoal = Integer.parseInt(TXTF_CGoal.getText());
        int uAmount = Integer.parseInt(TXTF_UAmount.getText());
        int uGoal = Integer.parseInt(TXTF_UGoal.getText());

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance", "root", "");
        } catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        try {
            pst = conn.prepareStatement("UPDATE tblauditing SET Techno_Amount=?,Techno_Goal=?,Charter_Amount=?,Charter_Goal=?,Umeet_Amount=?,Umeet_Goal=?");
            pst.setInt(1, tAmount);
            pst.setInt(2, tGoal);
            pst.setInt(3, cAmount);
            pst.setInt(4, cGoal);
            pst.setInt(5, uAmount);
            pst.setInt(6, uGoal);
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "All values are set!");
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("CAUTION!");
            alert.setHeaderText(null);
            alert.setContentText("All values are set, BUT you need to set again a payment for student who paid!");
            alert.showAndWait();
            
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
    }

}
