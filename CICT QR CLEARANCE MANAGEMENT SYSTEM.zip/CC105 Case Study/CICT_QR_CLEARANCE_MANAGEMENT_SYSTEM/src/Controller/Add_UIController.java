package Controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javax.swing.JOptionPane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import MainClass.Start;

public class Add_UIController implements Initializable {

    Connection conn;
    PreparedStatement pst;
    ResultSet rs;

    @FXML
    private BorderPane BDP_background;
    @FXML
    private TextField TXTF_studNum;
    @FXML
    private ComboBox COMBO_yearLevel;
    @FXML
    private ComboBox COMBO_section;
    @FXML
    private TextField TXTF_fName;
    @FXML
    private TextField TXTF_mName;
    @FXML
    private TextField TXTF_lName;
    @FXML
    private Button BTN_cancel;
    @FXML
    private Pane PANE_containerBlue;
    @FXML
    private Pane PANE_white;
    @FXML
    private Text TXT_title;
    @FXML
    private Circle SHAPE_circle;
    @FXML
    private ImageView IMAGE_add;
    @FXML
    private GridPane GRID_container;
    @FXML
    private Text TXT_studNum;
    @FXML
    private Text TXT_yearLevel;
    @FXML
    private Text TXT_section;
    @FXML
    private Text TXT_fullName;
    @FXML
    private Text TXT_fName;
    @FXML
    private Text TXT_mName;
    @FXML
    private Text TXT_lName;
    @FXML
    private Button BTN_addStud;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ObservableList yearLevels = FXCollections.observableArrayList("1st Year", "2nd Year", "3rd Year", "4th Year");
        COMBO_yearLevel.setItems(yearLevels);
        ObservableList studentSections = FXCollections.observableArrayList("All Sections", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
        COMBO_section.setItems(studentSections);
    }

    @FXML
    private void BTN_addStud(ActionEvent event) throws IOException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance", "root", "");
        } catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        String studentNumber = TXTF_studNum.getText();
        String studentFName = TXTF_fName.getText();
        if (studentFName.contains(" ")) {
            String studentFNameM = studentFName.replace(" ", "_");
            studentFName = studentFNameM;
        }
        String studentMName = TXTF_mName.getText();
        if (studentMName.contains(" ")) {
            String studentMNameM = studentMName.replace(" ", "_");
            studentMName = studentMNameM;
        }
        String studentLName = TXTF_lName.getText();
        if (studentLName.contains(" ")) {
            String studentLNameM = studentLName.replace(" ", "_");
            studentLName = studentLNameM;
        }
        String studentFullName = studentFName + " " + studentMName + " " + studentLName;
        String studentYearLvL = (String) COMBO_yearLevel.getValue();
        String studentSection = (String) COMBO_section.getValue();
        String TechnologyDay = "Unpaid";
        String CharterDay = "Unpaid";
        String UmeetDay = "Unpaid";
        String StudentStatus = "Not Ready";

        int y = 0;
        try {
            pst = conn.prepareStatement("SELECT * FROM tblstudents");
            rs = pst.executeQuery();

            while (rs.next()) {
                String idnumber = rs.getString("studId");
                String name = rs.getString("studName");

                if (studentNumber.equals(idnumber) || studentFullName.equals(name)) {
                    Alert alert = new Alert(AlertType.WARNING);
                    alert.setTitle("WARNING");
                    alert.setHeaderText(null);
                    alert.setContentText("This student already exists!");
                    alert.showAndWait();
                    y++;
                    break;
                }
            }
            if (y == 0) {
                if (!TXTF_studNum.getText().isEmpty() && !TXTF_fName.getText().isEmpty() && !TXTF_lName.getText().isEmpty() && COMBO_yearLevel.getValue() != null && COMBO_section.getValue() != null) {
                    try {
                        pst = conn.prepareStatement("INSERT INTO tblstudents(studId,studName,studYearlvl,studSection,TechnoD,CharterD,UmeetD,Status) VALUES (?,?,?,?,?,?,?,?)");
                        pst.setString(1, studentNumber);
                        pst.setString(2, studentFullName);
                        pst.setString(3, studentYearLvL);
                        pst.setString(4, studentSection);
                        pst.setString(5, TechnologyDay);
                        pst.setString(6, CharterDay);
                        pst.setString(7, UmeetDay);
                        pst.setString(8, StudentStatus);
                        int x = pst.executeUpdate();

                        if (x == 1) {
                            JOptionPane.showMessageDialog(null, "Student added to the Record!");
                            Parent Add = FXMLLoader.load(getClass().getResource("/FXML/Add_UI.fxml"));
                            Scene GoAdd = new Scene(Add);
                            Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                            appStage.setScene(GoAdd);
                            appStage.setMaximized(false);
                            appStage.setMaximized(true);
                            appStage.show();
                        } else {
                            JOptionPane.showMessageDialog(null, "Failed to add Student!");
                        }
                    } catch (SQLException ex) {
                        java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                    }
                } else {
                    Alert alert = new Alert(AlertType.WARNING);
                    alert.setTitle("WARNING");
                    alert.setHeaderText(null);
                    alert.setContentText("Please Fill up all the fields and select a Year level and Section of the student!");
                    alert.showAndWait();

                }
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
    }

    @FXML
    private void BTN_cancel(ActionEvent event) throws IOException {
        Parent Cancel = FXMLLoader.load(getClass().getResource("/FXML/Dashboard_Admin_UI.fxml"));
        Scene Back = new Scene(Cancel);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(Back);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
        
    }

}
