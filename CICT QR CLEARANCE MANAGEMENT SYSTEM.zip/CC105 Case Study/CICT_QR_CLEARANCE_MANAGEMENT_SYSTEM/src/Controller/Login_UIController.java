package Controller;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.CubicCurve;
import javafx.scene.shape.QuadCurve;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

import Encapsulation.EncapsulateValue;
import MainClass.Start;

public class Login_UIController implements Initializable {

    Connection conn;
    PreparedStatement pst;
    ResultSet rs;
    
    EncapsulateValue EV = EncapsulateValue.getInstance();

    @FXML
    private BorderPane BDP_background;
    @FXML
    private VBox VBOX_left;
    @FXML
    private Pane PANE_container;
    @FXML
    private Rectangle SHAPE_topYellow;
    @FXML
    private Rectangle SHAPE_topBlue;
    @FXML
    private Rectangle SHAPE_bottomYellow;
    @FXML
    private Rectangle SHAPE_bottomBlue;
    @FXML
    private CubicCurve SHAPE_curveYellow;
    @FXML
    private CubicCurve SHAPE_curveBlue;
    @FXML
    private QuadCurve SHAPE_curveWhite;
    @FXML
    private Text TXT_title;
    @FXML
    private Text TXT_subtitle;
    @FXML
    private Text TXT_loginBlue;
    @FXML
    private Text TXT_loginYellow;
    @FXML
    private TextField TXTF_email;
    @FXML
    private PasswordField PASSF_password;
    @FXML
    private Button BTN_login;
    @FXML
    private Hyperlink HPL_dont;
    @FXML
    private ImageView IMAGE_email;
    @FXML
    private ImageView IMAGE_password;
    @FXML
    private VBox VBOX_center;
    @FXML
    private Hyperlink HPL_forgot;
    @FXML
    private Pane PANE_iconBG1;
    @FXML
    private Pane PANE_iconBG2;
    @FXML
    private Tooltip TOOLTIP_email;
    @FXML
    private Tooltip TOOLTIP_password;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void BTN_login(ActionEvent event) throws IOException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance", "root", "");
        } catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        String pattern = "^TAL20|SUM20";
        String user = TXTF_email.getText();
        String pass = PASSF_password.getText();
        int y = 0;
        try {
            pst = conn.prepareStatement("SELECT * FROM tbluseraccount");
            rs = pst.executeQuery();

            while (rs.next()) {
                String email = rs.getString("USR_EADDRESS");
                String upass = rs.getString("USR_PASSWORD");
                String idnum = rs.getString("ID_NUM");
                String nname = rs.getString("USR_NAME");

                if (user.equals(email) && pass.equals(upass)) {
                    EV.setNickname(nname);

                    Pattern pt = Pattern.compile(pattern);
                    Matcher mt = pt.matcher(idnum);

                    boolean result = mt.find();

                    if (result == true) {
                        JOptionPane.showMessageDialog(null, "Hello, Admin " + nname + " Welcome!");
                        Parent Dashboard = FXMLLoader.load(getClass().getResource("/FXML/Dashboard_Admin_UI.fxml"));
                        Scene ShowDashboard = new Scene(Dashboard);
                        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        appStage.setScene(ShowDashboard);
                        appStage.setMaximized(false);
                        appStage.setMaximized(true);
                        appStage.show();
                        y++;
                        break;

                    } else {
                        JOptionPane.showMessageDialog(null, "Hello, User " + nname + " Welcome!");
                        Parent Dashboard = FXMLLoader.load(getClass().getResource("/FXML/Dashboard_User_UI.fxml"));
                        Scene ShowDashboard = new Scene(Dashboard);
                        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        appStage.setScene(ShowDashboard);
                        appStage.setMaximized(false);
                        appStage.setMaximized(true);
                        appStage.show();
                        y++;
                        break;
                    }

                }
            }
            if (y == 0) {
                JOptionPane.showMessageDialog(null, "Email and Password incorrect!");
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
    }

    @FXML
    private void HPL_dont(ActionEvent event) throws IOException {
        Parent SignUp = FXMLLoader.load(getClass().getResource("/FXML/SignUp_UI.fxml"));
        Scene GoSignUp = new Scene(SignUp);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(GoSignUp);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
        
    }

    @FXML
    private void HPL_forgot(ActionEvent event) throws IOException {
        Parent ForgotPass = FXMLLoader.load(getClass().getResource("/FXML/ForgotPassword_UI.fxml"));
        Scene GoForgotPass = new Scene(ForgotPass);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(GoForgotPass);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
    }
    
}
