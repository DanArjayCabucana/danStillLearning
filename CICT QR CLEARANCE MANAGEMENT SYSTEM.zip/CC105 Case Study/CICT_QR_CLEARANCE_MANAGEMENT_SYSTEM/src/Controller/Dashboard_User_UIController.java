package Controller;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType0Font;

import Encapsulation.EncapsulateValue;
import Encapsulation.StudentInformation;
import MainClass.Start;
import javafx.scene.control.Alert;

public class Dashboard_User_UIController implements Initializable {

    Connection conn;
    PreparedStatement pst;
    ResultSet rs;

    EncapsulateValue EV = EncapsulateValue.getInstance();
    ObservableList<StudentInformation> StudentList = FXCollections.observableArrayList();
    ObservableList<EncapsulateValue> AuditList = FXCollections.observableArrayList();
    
    @FXML
    private BorderPane BDP_backgroundDB;
    @FXML
    private GridPane GRID_left;
    @FXML
    private Text TXT_username;
    @FXML
    private ImageView IMAGE_print;
    @FXML
    private BorderPane BDP_container;
    @FXML
    private VBox VBOX_container;
    @FXML
    private GridPane GRID_top;
    @FXML
    private ComboBox COMBO_yearLevel;
    @FXML
    private ComboBox COMBO_section;
    @FXML
    private ComboBox COMBO_status;
    @FXML
    private TextField TXTF_search;
    @FXML
    private Tooltip TOOLTIP_search;
    @FXML
    private TableView<StudentInformation> TABLE_list;
    @FXML
    private TableColumn<StudentInformation, String> COLUMN_number;
    @FXML
    private TableColumn<StudentInformation, String> COLUMN_name;
    @FXML
    private TableColumn<StudentInformation, String> COLUMN_yearLevel;
    @FXML
    private TableColumn<StudentInformation, String> COLUMN_section;
    @FXML
    private TableColumn<StudentInformation, String> COLUMN_techno;
    @FXML
    private TableColumn<StudentInformation, String> COLUMN_charter;
    @FXML
    private TableColumn<StudentInformation, String> COLUMN_meet;
    @FXML
    private TableColumn<StudentInformation, String> COLUMN_status;
    @FXML
    private Button BTN_logOut;
    @FXML
    private ImageView IMAGE_logOut;
    @FXML
    private Label TXT_date;
    @FXML
    private Label TXT_time;
    @FXML
    private Rectangle SHAPE_line2;
    @FXML
    private Rectangle SHAPE_line3;
    @FXML
    private Line SHAPE_line1;
    @FXML
    private Text TXT_options;
    @FXML
    private ColumnConstraints COLUMN_1;
    @FXML
    private ColumnConstraints COLUMN_2;
    @FXML
    private ColumnConstraints COLUMN_3;
    @FXML
    private GridPane GRID_search;
    @FXML
    private ImageView IMAGE_search;
    @FXML
    private GridPane GRID_filter;
    @FXML
    private Pane PANE_3d3;
    @FXML
    private Pane PANE_3d2;
    @FXML
    private Pane PANE_3d1;
    @FXML
    private Circle SHAPE_circle;
    @FXML
    private ImageView IMAGE_filter;
    @FXML
    private Button BTN_tablePDF;
    @FXML
    private Button BTN_audit;
    @FXML
    private ImageView IMAGE_audit;
    @FXML
    private Text TXT_admin112;
    @FXML
    private Text TXT_totalTechno;
    @FXML
    private Text TXT_admin1122;
    @FXML
    private Text TXT_payedTechno;
    @FXML
    private Text TXT_admin11;
    @FXML
    private Text TXT_admin111;
    @FXML
    private Text TXT_targetTechno;
    @FXML
    private Text TXT_admin1121;
    @FXML
    private Text TXT_totalCharter;
    @FXML
    private Text TXT_admin11221;
    @FXML
    private Text TXT_payedCharter;
    @FXML
    private Text TXT_totalMeet;
    @FXML
    private Text TXT_admin11222;
    @FXML
    private Text TXT_payedMeet;
    @FXML
    private Text TXT_admin1112;
    @FXML
    private Text TXT_targetCharter;
    @FXML
    private Text TXT_admin11121;
    @FXML
    private Text TXT_targetMeet;
    @FXML
    private Text TXT_admin11111;
    @FXML
    private Text TXT_amountCharter;
    @FXML
    private Text TXT_admin111111;
    @FXML
    private Text TXT_amountTechno;
    @FXML
    private Text TXT_admin1111111;
    @FXML
    private Text TXT_amountMeet;
    @FXML
    private Text TXT_user;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ObservableList yearLevels = FXCollections.observableArrayList("All Levels", "1st Year", "2nd Year", "3rd Year", "4th Year");
        COMBO_yearLevel.setItems(yearLevels);
        ObservableList studentSections = FXCollections.observableArrayList("All Sections", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
        COMBO_section.setItems(studentSections);
        ObservableList status = FXCollections.observableArrayList("All", "Ready", "Not Ready");
        COMBO_status.setItems(status);

        String nickn = EV.getNickname();
        TXT_username.setText(nickn);

        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy");
        String formattedDate = currentDate.format(formatter);
        TXT_date.setText(formattedDate);

        Timeline clock = new Timeline(new KeyFrame(Duration.ZERO, e -> {
            LocalTime currentTime = LocalTime.now();
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a");
            String formattedTime = currentTime.format(timeFormatter);
            TXT_time.setText(formattedTime);
        }), new KeyFrame(Duration.seconds(1)));
        clock.setCycleCount(Animation.INDEFINITE);
        clock.play();

        loadTable();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance", "root", "");
        } catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        try {
            pst = conn.prepareStatement("SELECT * FROM tblstudents");
            rs = pst.executeQuery();

            while (rs.next()) {
                StudentList.add(new StudentInformation(
                        rs.getString("studId"),
                        rs.getString("studName"),
                        rs.getString("studYearlvl"),
                        rs.getString("studSection"),
                        rs.getString("TechnoD"),
                        rs.getString("CharterD"),
                        rs.getString("UmeetD"),
                        rs.getString("Status")));
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        try {
            pst = conn.prepareStatement("SELECT SUM(CASE WHEN TechnoD != 'Unpaid' THEN TechnoD ELSE 0 END) AS TechnoSum, " + "SUM(CASE WHEN CharterD != 'Unpaid' THEN CharterD ELSE 0 END) AS CharterSum, " + "SUM(CASE WHEN UmeetD != 'Unpaid' THEN UmeetD ELSE 0 END) AS UmeetSum, " + "COUNT(CASE WHEN TechnoD != 'Unpaid' THEN 1 END) AS TechnoCount, " + "COUNT(CASE WHEN CharterD != 'Unpaid' THEN 1 END) AS CharterCount, " + "COUNT(CASE WHEN UmeetD != 'Unpaid' THEN 1 END) AS UmeetCount " + "FROM tblstudents");
            rs = pst.executeQuery();

            while (rs.next()) {
                int technoSum = rs.getInt("TechnoSum");
                int charterSum = rs.getInt("CharterSum");
                int umeetSum = rs.getInt("UmeetSum");

                int technoCount = rs.getInt("TechnoCount");
                int charterCount = rs.getInt("CharterCount");
                int umeetCount = rs.getInt("UmeetCount");

                TXT_totalTechno.setText(Integer.toString(technoSum));
                TXT_totalCharter.setText(Integer.toString(charterSum));
                TXT_totalMeet.setText(Integer.toString(umeetSum));

                TXT_payedTechno.setText(Integer.toString(technoCount));
                TXT_payedCharter.setText(Integer.toString(charterCount));
                TXT_payedMeet.setText(Integer.toString(umeetCount));
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        try {
            pst = conn.prepareStatement("SELECT * FROM tblauditing");
            rs = pst.executeQuery();

            if (rs.next()) {
                EncapsulateValue value = new EncapsulateValue(
                        rs.getInt("Techno_Amount"),
                        rs.getInt("Techno_Goal"),
                        rs.getInt("Charter_Amount"),
                        rs.getInt("Charter_Goal"),
                        rs.getInt("Umeet_Amount"),
                        rs.getInt("Umeet_Goal")
                );
                AuditList.add(value);

                TXT_amountTechno.setText(String.valueOf(value.getT_Amount()));
                TXT_targetTechno.setText(String.valueOf(value.getT_Goal()));
                TXT_amountCharter.setText(String.valueOf(value.getC_Amount()));
                TXT_targetCharter.setText(String.valueOf(value.getC_Goal()));
                TXT_amountMeet.setText(String.valueOf(value.getU_Amount()));
                TXT_targetMeet.setText(String.valueOf(value.getU_Goal()));
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void BTN_logOut(ActionEvent event) throws IOException {
        Parent Logout = FXMLLoader.load(getClass().getResource("/FXML/Login_UI.fxml"));
        Scene GoLogin = new Scene(Logout);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(GoLogin);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
    }

    private void loadTable() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance", "root", "");
        } catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        COLUMN_number.setCellValueFactory(new PropertyValueFactory<>("id"));
        COLUMN_name.setCellValueFactory(new PropertyValueFactory<>("name"));
        COLUMN_yearLevel.setCellValueFactory(new PropertyValueFactory<>("year"));
        COLUMN_section.setCellValueFactory(new PropertyValueFactory<>("section"));
        COLUMN_techno.setCellValueFactory(new PropertyValueFactory<>("Tech"));
        COLUMN_charter.setCellValueFactory(new PropertyValueFactory<>("Charter"));
        COLUMN_meet.setCellValueFactory(new PropertyValueFactory<>("Umeet"));
        COLUMN_status.setCellValueFactory(new PropertyValueFactory<>("Stats"));

        TABLE_list.setItems(StudentList);

        FilteredList<StudentInformation> filteredData = new FilteredList<>(StudentList, b -> true);

        TXTF_search.textProperty().addListener((observable, oldValue, newValue) -> {
            if (TXTF_search != null) {
                COMBO_yearLevel.setValue("All Levels");
                COMBO_section.setValue("All Sections");
                COMBO_status.setValue("All");
            }
            filteredData.setPredicate(studentInformation -> {
                if (newValue.isEmpty() || newValue.isBlank()) {
                    return true;
                }

                String searchKeyword = newValue.toLowerCase();

                if (studentInformation.getId().toLowerCase().contains(searchKeyword)) {
                    return true;
                } else if (studentInformation.getName().toLowerCase().contains(searchKeyword)) {
                    return true;
                } else if (studentInformation.getYear().toLowerCase().contains(searchKeyword)) {
                    return true;
                } else return studentInformation.getSection().toLowerCase().contains(searchKeyword);
            });
        });

        SortedList<StudentInformation> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(TABLE_list.comparatorProperty());
        TABLE_list.setItems(sortedData);

        COMBO_yearLevel.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(data -> {
                String selectedSection = (String) COMBO_section.getSelectionModel().getSelectedItem();
                String selectedStatus = (String) COMBO_status.getSelectionModel().getSelectedItem();
                if (newValue == null || newValue.equals("All Levels")) {
                    return (selectedSection == null || selectedSection.equals("All Sections") || data.getSection().equals(selectedSection)) && (selectedStatus == null || selectedStatus.equals("All") || data.getStats().equals(selectedStatus));
                }
                return data.getYear().equals(newValue) && (selectedSection == null || selectedSection.equals("All Sections") || data.getSection().equals(selectedSection)) && (selectedStatus == null || selectedStatus.equals("All") || data.getStats().equals(selectedStatus));
            });
        });

        COMBO_section.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(data -> {
                String selectedYearLevel = (String) COMBO_yearLevel.getSelectionModel().getSelectedItem();
                String selectedStatus = (String) COMBO_status.getSelectionModel().getSelectedItem();
                if (newValue == null || newValue.equals("All Sections")) {
                    return (selectedYearLevel == null || selectedYearLevel.equals("All Levels") || data.getYear().equals(selectedYearLevel)) && (selectedStatus == null || selectedStatus.equals("All") || data.getStats().equals(selectedStatus));
                }
                return data.getSection().equals(newValue) && (selectedYearLevel == null || selectedYearLevel.equals("All Levels") || data.getYear().equals(selectedYearLevel)) && (selectedStatus == null || selectedStatus.equals("All") || data.getStats().equals(selectedStatus));
            });
        });

        COMBO_status.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(data -> {
                String selectedYearLevel = (String) COMBO_yearLevel.getSelectionModel().getSelectedItem();
                String selectedSection = (String) COMBO_section.getSelectionModel().getSelectedItem();
                if (newValue == null || newValue.equals("All")) {
                    return (selectedYearLevel == null || selectedYearLevel.equals("All Levels") || data.getYear().equals(selectedYearLevel)) && (selectedSection == null || selectedSection.equals("All Sections") || data.getSection().equals(selectedSection));
                }
                return data.getStats().equals(newValue) && (selectedYearLevel == null || selectedYearLevel.equals("All Levels") || data.getYear().equals(selectedYearLevel)) && (selectedSection == null || selectedSection.equals("All Sections") || data.getSection().equals(selectedSection));
            });
        });

    }

    @FXML
    private void BTN_tablePDF(ActionEvent event) {
        if (TABLE_list.getItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Empty Table");
            alert.setHeaderText(null);
            alert.setContentText("No data in the table to generate PDF.");
            alert.showAndWait();
            return;
        }
        
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);

            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                float margin = 50;
                float tableWidth = page.getMediaBox().getWidth() - 2 * margin;
                float yStart = page.getMediaBox().getHeight() - margin;
                float yEnd = margin;
                float cellMargin = 5;

                float[] columnWidths = {95, 200, 60, 45, 50, 50, 50};
                float rowHeight = 20;

                float totalColumnWidth = 0;
                for (float columnWidth : columnWidths) {
                    totalColumnWidth += columnWidth;
                }

                float xStart = (page.getMediaBox().getWidth() - totalColumnWidth) / 2;

                String title = "Student Status Report";
                contentStream.setFont(PDType0Font.load(document, getClass().getResourceAsStream("/org/apache/pdfbox/resources/ttf/LiberationSans-Bold.ttf")), 14);
                float titleWidth = PDType0Font.load(document, getClass().getResourceAsStream("/org/apache/pdfbox/resources/ttf/LiberationSans-Regular.ttf")).getStringWidth(title) / 1000 * 14;
                float titleX = (page.getMediaBox().getWidth() - titleWidth) / 2;
                contentStream.beginText();
                contentStream.newLineAtOffset(titleX, yStart);
                contentStream.showText(title);
                contentStream.endText();
                yStart -= rowHeight;

                String[] headers = {"ID Number", "Student Name", "Year Level", "Section", "Techno", "Charter", "Umeet"};
                drawTableRow(contentStream, document, headers, columnWidths, yStart, rowHeight, true, xStart);

                yStart -= rowHeight;
                for (StudentInformation student : TABLE_list.getItems()) {
                    String[] rowData = {student.getId(), student.getName(), student.getYear(), student.getSection(), student.getTech(), student.getCharter(), student.getUmeet()};
                    drawTableRow(contentStream, document, rowData, columnWidths, yStart, rowHeight, false, xStart);
                    yStart -= rowHeight;
                }

                drawTableBorders(contentStream, xStart, yStart, yEnd, totalColumnWidth, rowHeight, columnWidths);
            }

            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save PDF File");
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
            File file = fileChooser.showSaveDialog(null);
            if (file != null) {
                document.save(file);
            }
        } catch (IOException e) {
        }
        
    }

    private void drawTableRow(PDPageContentStream contentStream, PDDocument document, String[] rowData, float[] columnWidths, float yStart, float rowHeight, boolean isHeader, float xStart) throws IOException {
        float y = yStart;
        contentStream.setFont(PDType0Font.load(document, getClass().getResourceAsStream("/org/apache/pdfbox/resources/ttf/LiberationSans-Regular.ttf")), 10);
        float x = xStart;

        for (int i = 0; i < rowData.length; i++) {
            float textWidth = PDType0Font.load(document, getClass().getResourceAsStream("/org/apache/pdfbox/resources/ttf/LiberationSans-Regular.ttf")).getStringWidth(rowData[i]) / 1000 * 10;
            float centerX = x + (columnWidths[i] - textWidth) / 2;

            contentStream.addRect(x, y - rowHeight, columnWidths[i], rowHeight);
            contentStream.stroke();

            boolean isCenteredColumn = (i == 2 || i == 3 || i == 4 || i == 5 || i == 6);

            float textXOffset;
            if (isHeader) {
                contentStream.setFont(PDType0Font.load(document, getClass().getResourceAsStream("/org/apache/pdfbox/resources/ttf/LiberationSans-Bold.ttf")), 10);
                textXOffset = centerX;
            } else if (isCenteredColumn) {
                textXOffset = centerX;
            } else {
                textXOffset = x + 2;
            }

            contentStream.beginText();
            contentStream.newLineAtOffset(textXOffset, y - 12);
            contentStream.showText(rowData[i]);
            contentStream.endText();

            x += columnWidths[i];
        }
        
    }

    private void drawTableBorders(PDPageContentStream contentStream, float xStart, float yStart, float yEnd, float tableWidth, float rowHeight, float[] columnWidths) throws IOException {
        float y = yStart;
        float x = xStart;

        for (int i = 0; i <= TABLE_list.getItems().size() + 1; i++) {
            contentStream.moveTo(x, y);
            contentStream.stroke();
            y -= rowHeight;
        }

        y = yStart;
        for (int i = 0; i < columnWidths.length; i++) {
            contentStream.moveTo(x, y);
            contentStream.stroke();
            x += columnWidths[i];
        }
        
    }

    @FXML
    private void BTN_audit(ActionEvent event) throws IOException {
        Parent Auiditing = FXMLLoader.load(getClass().getResource("/FXML/Audit_User_UI.fxml"));
        Scene ShowData = new Scene(Auiditing);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(ShowData);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
        
    }
    
}
