package Controller;

import java.sql.*;
import java.io.IOException;
import java.net.URL;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

import Encapsulation.EncapsulateValue;
import MainClass.Start;

public class Delete_UIController implements Initializable {

    Connection conn;
    PreparedStatement pst;
    ResultSet rs;
 
    EncapsulateValue EV = EncapsulateValue.getInstance();

    @FXML
    private BorderPane BDP_background;
    @FXML
    private Pane PANE_container;
    @FXML
    private Button BTN_noDelete;
    @FXML
    private Circle SHAPE_circle;
    @FXML
    private Text TXT_studName;
    @FXML
    private Pane PANE_white;
    @FXML
    private GridPane GRID_top;
    @FXML
    private Text TXT_label;
    @FXML
    private Line SHAPE_line;
    @FXML
    private Button BTN_deleted;
    @FXML
    private Text TXT_title;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String studid = EV.getStudId();
        String studname = EV.getStudName();
        if (studname.contains("_")) {
            String studnameM = studname.replace("_", " ");
            studname = studnameM;
        }
        TXT_studName.setText(studname);
        
    }

    @FXML
    private void BTN_yesDelete(ActionEvent event) throws IOException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance", "root", "");
        } catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        String studid = EV.getStudId();
        String studname = EV.getStudName();

        try {
            pst = conn.prepareStatement("SELECT * FROM tblstudents");
            rs = pst.executeQuery();

            while (rs.next()) {
                String idnumber = rs.getString("studId");
                String name = rs.getString("studName");

                if (studid.equals(idnumber) && studname.equals(name)) {
                    pst = conn.prepareStatement("DELETE FROM tblstudents WHERE studId=? AND studName=?");
                    pst.setString(1, studid);
                    pst.setString(2, studname);
                    pst.executeUpdate();

                    JOptionPane.showMessageDialog(null, "Student Deleted Successfuly!");
                    Parent Dashboard = FXMLLoader.load(getClass().getResource("/FXML/Dashboard_Admin_UI.fxml"));
                    Scene ShowDashboard = new Scene(Dashboard);
                    Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    appStage.setScene(ShowDashboard);
                    appStage.setMaximized(false);
                    appStage.setMaximized(true);
                    appStage.show();
                }
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
    }

    @FXML
    private void BTN_noDelete(ActionEvent event) throws IOException {
        Parent Cancel = FXMLLoader.load(getClass().getResource("/FXML/Dashboard_Admin_UI.fxml"));
        Scene Back = new Scene(Cancel);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(Back);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
        
    }

}
