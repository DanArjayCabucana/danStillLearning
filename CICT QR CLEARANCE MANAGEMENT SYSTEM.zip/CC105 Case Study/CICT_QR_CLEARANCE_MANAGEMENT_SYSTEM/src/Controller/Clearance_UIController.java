package Controller;

import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import java.io.ByteArrayInputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import net.glxn.qrgen.QRCode;
import net.glxn.qrgen.image.ImageType;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.ModuleLayer.Controller;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.print.PageLayout;
import javafx.print.PageOrientation;
import javafx.print.Paper;
import javafx.print.Printer;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

import Encapsulation.EncapsulateValue;

public class Clearance_UIController implements Initializable {

    EncapsulateValue EV = EncapsulateValue.getInstance();
    
    @FXML
    private BorderPane BDP_background;
    @FXML
    private BorderPane BDP_bottom;
    @FXML
    private Pane PANE_bottomYellow;
    @FXML
    private Button BTN_generate;
    @FXML
    private Button BTN_cancel;
    @FXML
    private Pane PANE_container1;
    @FXML
    private GridPane GRID_1;
    @FXML
    private Text TXT_title;
    @FXML
    private Text TXT_dateTitle;
    @FXML
    private Label TXT_date;
    @FXML
    private Rectangle SHAPE_qrContainer;
    @FXML
    private GridPane GRID_2;
    @FXML
    private Rectangle SHAPE_line1;
    @FXML
    private Text TXT_label1;
    @FXML
    private Text TXT_studentName;
    @FXML
    private GridPane GRID_3;
    @FXML
    private Text TXT_label2;
    @FXML
    private Text TXT_studentNumber;
    @FXML
    private Rectangle SHAPE_line2;
    @FXML
    private GridPane GRID_4;
    @FXML
    private Text TXT_label3;
    @FXML
    private Text TXT_yearSection;
    @FXML
    private Rectangle SHAPE_line3;
    @FXML
    private GridPane GRID_7;
    @FXML
    private Line SHAPE_line4;
    @FXML
    private Text TXT_label9;
    @FXML
    private ImageView qrCode;
    @FXML
    private Button BTN_generateQR;
    @FXML
    private ImageView IMG_Signature;
    @FXML
    private Button BTN_signature;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy");
        String formattedDate = currentDate.format(formatter);
        TXT_date.setText(formattedDate);

        String studname = EV.getStudName();
        String studid = EV.getStudId();
        String studyear = EV.getStudYearLevel();
        String studsection = EV.getStudSection();

        TXT_studentName.setText(studname);
        TXT_studentNumber.setText(studid);
        TXT_yearSection.setText(studyear + " / Section " + studsection);
        
    }

    @FXML
    private void BTN_generate(ActionEvent event) {
        Pane printPane = new Pane();
        printPane.getChildren().addAll(PANE_container1);

        PANE_container1.setLayoutX(1);
        PANE_container1.setLayoutY(0);

        printPane.setPrefWidth(1500);
        printPane.setPrefHeight(2500);

        Printer printer = Printer.getDefaultPrinter();
        PageLayout pageLayout = printer.createPageLayout(Paper.A4, PageOrientation.PORTRAIT, 0, 0, 0, 0);
        PrinterJob job = PrinterJob.createPrinterJob(printer);

        if (job != null) {
            job.getJobSettings().setPageLayout(pageLayout);

            boolean showDialog = job.showPageSetupDialog(null);
            if (showDialog) {
                double scaleX = pageLayout.getPrintableWidth() / printPane.getPrefWidth();
                double scaleY = pageLayout.getPrintableHeight() / printPane.getPrefHeight();
                printPane.getTransforms().add(new Scale(scaleX, scaleY));

                boolean success = job.printPage(printPane);
                if (success) {
                    JOptionPane.showMessageDialog(null, "Generated PDF Success!");
                    job.endJob();
                } else {
                    JOptionPane.showMessageDialog(null, "Generated PDF Canceled!");
                }
            }
        }
        
    }

    @FXML
    private void BTN_cancel(ActionEvent event) throws IOException {
        Parent Cancel = FXMLLoader.load(getClass().getResource("/FXML/Dashboard_Admin_UI.fxml"));
        Scene Back = new Scene(Cancel);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(Back);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
        
    }
    
    @FXML
    private void BTN_generateQR(ActionEvent event) {
        String studname = EV.getStudName();
        String studid = EV.getStudId();
        String studyear = EV.getStudYearLevel();
        String studsection = EV.getStudSection();

        String qrContent = "Name: " + studname + "\nStudent Number: " + studid + "\nYear Level: " + studyear + "\nSection: " + studsection;

        try {
            ByteArrayOutputStream out = QRCode.from(qrContent).to(ImageType.PNG).stream();
            ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
            Image image = new Image(in);

            qrCode.setImage(image);
            qrCode.setFitWidth(150);
            qrCode.setFitHeight(150);

            BTN_generate.setDisable(false);
            BTN_generateQR.setDisable(true);

        } catch (Exception ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Error generating QR code: " + ex.getMessage());
            alert.showAndWait();
        }
        
    }

    @FXML
    private void BTN_signature(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Image Signature");
        File file = fileChooser.showOpenDialog(((Node) event.getSource()).getScene().getWindow());

        if (file == null) {
            JOptionPane.showMessageDialog(null, "Please select e-signature first!");
            return;
        }

        Image image = new Image(file.toURI().toString());
        IMG_Signature.setImage(image);
        IMG_Signature.setFitWidth(130);
        IMG_Signature.setFitHeight(90);

        BTN_generate.setDisable(false);
    }

}
