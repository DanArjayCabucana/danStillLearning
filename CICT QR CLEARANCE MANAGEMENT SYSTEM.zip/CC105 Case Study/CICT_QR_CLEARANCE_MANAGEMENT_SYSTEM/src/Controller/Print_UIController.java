package Controller;

import java.io.IOException;
import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.print.PageLayout;
import javafx.print.PageOrientation;
import javafx.print.Paper;
import javafx.print.Printer;
import javafx.print.PrinterJob;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.transform.Scale;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

import Encapsulation.EncapsulateValue;
import MainClass.Start;


public class Print_UIController implements Initializable {

    Connection conn;
    PreparedStatement pst;
    ResultSet rs;
    
    EncapsulateValue EV = EncapsulateValue.getInstance();
    ObservableList<EncapsulateValue> AuditList = FXCollections.observableArrayList();
    
    @FXML
    private BorderPane BDP_background;
    @FXML
    private BorderPane BDP_bottom;
    @FXML
    private Pane PANE_bottomYellow;
    @FXML
    private Button BTN_cancel;
    @FXML
    private Pane PANE_container1;
    @FXML
    private GridPane GRID_1;
    @FXML
    private Text TXT_studNum1;
    @FXML
    private Text TXT_dateTitle;
    @FXML
    private GridPane GRID_2;
    @FXML
    private Text TXT_label1;
    @FXML
    private Text TXT_studentName;
    @FXML
    private Rectangle SHAPE_line1;
    @FXML
    private GridPane GRID_3;
    @FXML
    private Text TXT_label2;
    @FXML
    private Text TXT_studentNumber;
    @FXML
    private Rectangle SHAPE_line2;
    @FXML
    private GridPane GRID_4;
    @FXML
    private Text TXT_label3;
    @FXML
    private Text TXT_yearSection;
    @FXML
    private Rectangle SHAPE_line3;
    @FXML
    private GridPane GRID_5;
    @FXML
    private Text TXT_label4;
    @FXML
    private ComboBox COMBO_event;
    @FXML
    private GridPane GRID_6;
    @FXML
    private Text TXT_label5;
    @FXML
    private Text TXT_label6;
    @FXML
    private TextField TXTF_charter;
    @FXML
    private Text TXT_label7;
    @FXML
    private TextField TXTF_techno;
    @FXML
    private Text TXT_label8;
    @FXML
    private TextField TXTF_meet;
    @FXML
    private GridPane GRID_7;
    @FXML
    private Text TXT_label9;
    @FXML
    private Button BTN_generate;
    @FXML
    private Label TXT_date;
    @FXML
    private Line SHAPE_line41;
    @FXML
    private ImageView IMG_Signature;
    @FXML
    private Button BTN_Signature;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy");
        String formattedDate = currentDate.format(formatter);
        TXT_date.setText(formattedDate);
        
        ObservableList eventType = FXCollections.observableArrayList("All", "Charter", "Techno", "Umeet", "Charter & Techno", "Charter & Umeet", "Techno & Umeet");
        COMBO_event.setItems(eventType);
        
        String studname = EV.getStudName();
        String studid = EV.getStudId();
        String studyear = EV.getStudYearLevel();
        String studsection = EV.getStudSection();
        String charter = EV.getCharter();
        String techno = EV.getTech();
        String umeet = EV.getUmeet();
        
        if(charter.equals("Unpaid") ) {
            TXTF_charter.setText("");
        } else {
            TXTF_charter.setText(charter);
        }

        if(techno.equals("Unpaid")) {
            TXTF_techno.setText("");
        } else {
            TXTF_techno.setText(techno);
        }

        if(umeet.equals("Unpaid")) {
            TXTF_meet.setText("");
        } else {
            TXTF_meet.setText(umeet);
        }
        
        TXT_studentName.setText(studname);
        TXT_studentNumber.setText(studid);
        TXT_yearSection.setText(studyear+" / Section "+studsection);
        
    }    

    @FXML
    private void SELECT_event(ActionEvent event) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance","root","");
        }catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        try {
        pst = conn.prepareStatement("SELECT * FROM tblauditing");
        rs = pst.executeQuery();

            if (rs.next()) {
                int technoAmount = rs.getInt("Techno_Amount");
                int charterAmount = rs.getInt("Charter_Amount");
                int umeetAmount = rs.getInt("Umeet_Amount");

                String selectedEvent = (String) COMBO_event.getSelectionModel().getSelectedItem();

                if (selectedEvent != null) {
                    switch (selectedEvent) {
                        case "All" -> {
                            TXTF_charter.setText(Integer.toString(charterAmount));
                            TXTF_techno.setText(Integer.toString(technoAmount));
                            TXTF_meet.setText(Integer.toString(umeetAmount));
                        }
                        case "Charter" -> {
                            TXTF_charter.setText(Integer.toString(charterAmount));
                            TXTF_techno.setText("");
                            TXTF_meet.setText("");
                        }
                        case "Techno" -> {
                            TXTF_charter.setText("");
                            TXTF_techno.setText(Integer.toString(technoAmount));
                            TXTF_meet.setText("");
                        }
                        case "Umeet" -> {
                            TXTF_charter.setText("");
                            TXTF_techno.setText("");
                            TXTF_meet.setText(Integer.toString(umeetAmount));
                        }
                        case "Charter & Techno" -> {
                            TXTF_charter.setText(Integer.toString(charterAmount));
                            TXTF_techno.setText(Integer.toString(technoAmount));
                            TXTF_meet.setText("");
                        }
                        case "Charter & Umeet" -> {
                            TXTF_charter.setText(Integer.toString(charterAmount));
                            TXTF_techno.setText("");
                            TXTF_meet.setText(Integer.toString(umeetAmount));
                        }
                        case "Techno & Umeet" -> {
                            TXTF_charter.setText("");
                            TXTF_techno.setText(Integer.toString(technoAmount));
                            TXTF_meet.setText(Integer.toString(umeetAmount));
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void BTN_cancel(ActionEvent event) throws IOException{
        JOptionPane.showMessageDialog(null, "Cancelled Transaction!");
        Parent Cancel = FXMLLoader.load(getClass().getResource("/FXML/Dashboard_Admin_UI.fxml"));
        Scene Back = new Scene(Cancel);
        Stage appStage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        appStage.setScene(Back);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
        
    }

    @FXML
    private void BTN_generate(ActionEvent event) throws IOException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance","root","");
        } catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        String studname = EV.getStudName();
        String studid = EV.getStudId();

        String C_Amount = TXTF_charter.getText();
        String T_Amount = TXTF_techno.getText();
        String U_Amount = TXTF_meet.getText();

        if (conn != null) {
            try {
                pst = conn.prepareStatement("SELECT * FROM tblstudents WHERE studId=? AND studName=?");
                pst.setString(1, studid);
                pst.setString(2, studname);
                rs = pst.executeQuery();

                if (rs.next()) {
                    Pane printPane = new Pane();
                    printPane.getChildren().add(PANE_container1);
                    PANE_container1.setLayoutX(1);
                    PANE_container1.setLayoutY(0);
                    printPane.setPrefWidth(1500);
                    printPane.setPrefHeight(2500); 

                    Printer printer = Printer.getDefaultPrinter();
                    PageLayout pageLayout = printer.createPageLayout(Paper.A4, PageOrientation.PORTRAIT,0,0,0,0);
                    PrinterJob job = PrinterJob.createPrinterJob(printer);
                    if (job != null) {
                        job.getJobSettings().setPageLayout(pageLayout);

                        boolean showDialog = job.showPageSetupDialog(null);
                        if (showDialog) {
                            double scaleX = pageLayout.getPrintableWidth() / printPane.getPrefWidth();
                            double scaleY = pageLayout.getPrintableHeight() / printPane.getPrefHeight();
                            printPane.getTransforms().add(new Scale(scaleX, scaleY));

                            boolean success = job.printPage(printPane);
                            if (success) {
                                String updateQuery = "UPDATE tblstudents SET ";
                                List<String> transact = new ArrayList<>();

                                if (!C_Amount.equals("")) {
                                    transact.add("CharterD='" + C_Amount + "'");
                                } else {
                                    transact.add("CharterD='Unpaid'");
                                }

                                if (!T_Amount.equals("")) {
                                    transact.add("TechnoD='" + T_Amount + "'");
                                } else {
                                    transact.add("TechnoD='Unpaid'");
                                }

                                if (!U_Amount.equals("")) {
                                    transact.add("UmeetD='" + U_Amount + "'");
                                } else {
                                    transact.add("UmeetD='Unpaid'");
                                }

                                if (!C_Amount.equals("") && !T_Amount.equals("") && !U_Amount.equals("")) {
                                    transact.add("Status='Ready'");
                                } else {
                                    transact.add("Status='Not Ready'");
                                }

                                updateQuery += String.join(",", transact) + " WHERE studId='" + studid + "'";
                                pst = conn.prepareStatement(updateQuery);
                                int rowsAffected = pst.executeUpdate();

                                if (rowsAffected > 0) {
                                    JOptionPane.showMessageDialog(null, "Successful Transaction!");
                                    JOptionPane.showMessageDialog(null, "You'll be directed to Dashboard!");
                                    job.endJob();
                                    Parent PrintTransact = FXMLLoader.load(getClass().getResource("/FXML/Dashboard_Admin_UI.fxml"));
                                    Scene GoPrint = new Scene(PrintTransact);
                                    Stage appStage = (Stage) ((Node)event.getSource()).getScene().getWindow();
                                    appStage.setScene(GoPrint);
                                    appStage.setMaximized(false);
                                    appStage.setMaximized(true);
                                    appStage.show();
                                } else {
                                    JOptionPane.showMessageDialog(null, "Unsuccessful Transaction!");
                                }
                            }
                        }
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "Student not found!");
                }
            } catch (SQLException ex) {
                java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Database connection failed!");
        }
        
    }

    @FXML
    private void BTN_Signature(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Image Signature");
        File file = fileChooser.showOpenDialog(((Node) event.getSource()).getScene().getWindow());

        if (file == null) {
            JOptionPane.showMessageDialog(null, "Please select e-signature first!");
            return;
        }

        Image image = new Image(file.toURI().toString());
        IMG_Signature.setImage(image);
        IMG_Signature.setFitWidth(130);
        IMG_Signature.setFitHeight(90);

        BTN_generate.setDisable(false);
    }

}
