package Controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

import Encapsulation.EncapsulateValue;
import MainClass.Start;

public class Edit_UIController implements Initializable {

    Connection conn;
    PreparedStatement pst;
    ResultSet rs;
    
    EncapsulateValue EV = EncapsulateValue.getInstance();

    String Fname = "";
    String Mname = "";
    String Lname = "";

    @FXML
    private BorderPane BDP_background;
    @FXML
    private GridPane GRID_top;
    @FXML
    private Text TXT_studName;
    @FXML
    private Line SHAPE_line;
    @FXML
    private Text TXT_label;
    @FXML
    private GridPane GRID_bottom;
    @FXML
    private TextField TXTF_studNum;
    @FXML
    private ComboBox COMBO_yearLevel;
    @FXML
    private ComboBox COMBO_section;
    @FXML
    private Text TXT_fullname;
    @FXML
    private TextField TXTF_fName;
    @FXML
    private TextField TXTF_mName;
    @FXML
    private TextField TXTF_lName;
    @FXML
    private Button BTN_saveEdit;
    @FXML
    private Button BTN_cancel;
    @FXML
    private Pane PANE_containerBlue;
    @FXML
    private Pane PANE_white;
    @FXML
    private Text TXT_title;
    @FXML
    private Circle SHAPE_circle;
    @FXML
    private ImageView IMAGE_edit;
    @FXML
    private Text TXT_StudentNumber;
    @FXML
    private Text TXT_YearLevel;
    @FXML
    private Text TXT_Section;
    @FXML
    private Text TXT_FirstName;
    @FXML
    private Text TXT_MIddleName;
    @FXML
    private Text TXT_LastName;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ObservableList yearLevels = FXCollections.observableArrayList("1st Year", "2nd Year", "3rd Year", "4th Year");
        COMBO_yearLevel.setItems(yearLevels);
        ObservableList studentSections = FXCollections.observableArrayList("A", "B", "C", "D");
        COMBO_section.setItems(studentSections);

        String studid = EV.getStudId();
        String studname = EV.getStudName();
        String Firstname = "";
        String MIddlename = "";
        String Lastname = "";
        String[] parts = studname.split(" ");

        if (parts.length == 1) {
            Firstname = parts[0];
        } else if (parts.length == 2) {
            Firstname = parts[0];
            Lastname = parts[1];
        } else if (parts.length >= 3) {
            Firstname = parts[0];
            MIddlename = parts[1];

            for (int i = 2; i < parts.length; i++) {
                Lastname += parts[i];
                if (i < parts.length - 1) {
                    Lastname += " ";
                }
            }
        }
        if (Firstname.contains("_")) {
            String FnameM = Firstname.replace("_", " ");
            Firstname = FnameM;
        }
        if (MIddlename.contains("_")) {
            String MnameM = MIddlename.replace("_", " ");
            MIddlename = MnameM;
        }
        if (Lastname.contains("_")) {
            String LnameM = Lastname.replace("_", " ");
            Lastname = LnameM;
        }

        if (studname.contains("_")) {
            String studnameM = studname.replace("_", " ");
            studname = studnameM;
        }
        String studyear = EV.getStudYearLevel();
        String studsection = EV.getStudSection();
        TXT_studName.setText(studname);
        TXTF_studNum.setText(studid);
        COMBO_yearLevel.setValue(studyear);
        COMBO_section.setValue(studsection);
        TXTF_fName.setText(Firstname);
        TXTF_mName.setText(MIddlename);
        TXTF_lName.setText(Lastname);

    }

    @FXML
    private void BTN_saveEdit(ActionEvent event) throws IOException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance", "root", "");
        } catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        String studid = EV.getStudId();
        String studname = EV.getStudName();
        String studyearlevel = EV.getStudYearLevel();
        String studsection = EV.getStudSection();

        String studentNumber = TXTF_studNum.getText();
        String studentFName = TXTF_fName.getText();
        if (studentFName.contains(" ")) {
            String studentFNameM = studentFName.replace(" ", "_");
            studentFName = studentFNameM;
        }
        String studentMName = TXTF_mName.getText();
        if (studentMName.contains(" ")) {
            String studentMNameM = studentMName.replace(" ", "_");
            studentMName = studentMNameM;
        }
        String studentLName = TXTF_lName.getText();
        if (studentLName.contains(" ")) {
            String studentLNameM = studentLName.replace(" ", "_");
            studentLName = studentLNameM;
        }
        String studentFullName = studentFName + " " + studentMName + " " + studentLName;
        String studentYearLvL = (String) COMBO_yearLevel.getValue();
        String studentSection = (String) COMBO_section.getValue();

        int y = 0;
        try {
            pst = conn.prepareStatement("SELECT * FROM tblstudents");
            rs = pst.executeQuery();

            while (rs.next()) {
                String idnumber = rs.getString("studId");
                String name = rs.getString("studName");
                String year = rs.getString("studYearlvl");
                String section = rs.getString("studSection");

                if (studid.equals(idnumber) && studname.equals(name)) {
                    y++;
                    break;
                }
            }
            if (y == 1) {
                if (!TXTF_studNum.getText().isEmpty() && !TXTF_fName.getText().isEmpty() && !TXTF_mName.getText().isEmpty() && !TXTF_lName.getText().isEmpty() && COMBO_yearLevel.getValue() != null && COMBO_section.getValue() != null) {
                    try {
                        pst = conn.prepareStatement("UPDATE tblstudents SET studId=?,studName=?,studYearlvl=?,studSection=? WHERE studId='" + studid + "'");
                        pst.setString(1, studentNumber);
                        pst.setString(2, studentFullName);
                        pst.setString(3, studentYearLvL);
                        pst.setString(4, studentSection);
                        int x = pst.executeUpdate();

                        if (x == 1) {
                            JOptionPane.showMessageDialog(null, "Edited Successfully!");
                            Parent Dashboard = FXMLLoader.load(getClass().getResource("/FXML/Dashboard_Admin_UI.fxml"));
                            Scene ShowDashboard = new Scene(Dashboard);
                            Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                            appStage.setScene(ShowDashboard);
                            appStage.setMaximized(false);
                            appStage.setMaximized(true);
                            appStage.show();
                        } else {
                            JOptionPane.showMessageDialog(null, "Failed to edit Student!");
                        }
                    } catch (SQLException ex) {
                        java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("WARNING");
                    alert.setHeaderText(null);
                    alert.setContentText("Please Fill up all the fields and select a Year level and Section of the student!");
                    alert.showAndWait();
                }
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
    }

    @FXML
    private void BTN_cancel(ActionEvent event) throws IOException {
        Parent Cancel = FXMLLoader.load(getClass().getResource("/FXML/Dashboard_Admin_UI.fxml"));
        Scene Back = new Scene(Cancel);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(Back);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
        
    }

    private void CB_studNum(ActionEvent event) {
        TXTF_studNum.setEditable(true);
        
    }

}
