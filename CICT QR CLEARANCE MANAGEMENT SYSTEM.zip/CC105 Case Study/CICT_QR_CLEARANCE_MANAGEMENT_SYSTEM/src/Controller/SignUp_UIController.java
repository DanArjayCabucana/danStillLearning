package Controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.CubicCurve;
import javafx.scene.shape.QuadCurve;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

import MainClass.Start;

public class SignUp_UIController implements Initializable {

    Connection conn;
    PreparedStatement pst;
    ResultSet rs;

    @FXML
    private BorderPane BDP_background;
    @FXML
    private VBox VBOX_left;
    @FXML
    private Pane PANE_container;
    @FXML
    private Rectangle SHAPE_topYellow;
    @FXML
    private Rectangle SHAPE_topBlue;
    @FXML
    private Rectangle SHAPE_bottomYellow;
    @FXML
    private Rectangle SHAPE_bottomBlue;
    @FXML
    private CubicCurve SHAPE_curveYellow;
    @FXML
    private CubicCurve SHAPE_curveBlue;
    @FXML
    private QuadCurve SHAPE_curveWhite;
    @FXML
    private Text TXT_title;
    @FXML
    private Text TXT_subtitle;
    @FXML
    private Text TXT_signupBlue;
    @FXML
    private Text TXT_signupYellow;
    @FXML
    private TextField TXTF_email;
    @FXML
    private PasswordField PASSF_password;
    @FXML
    private PasswordField PASSF_confirm;
    @FXML
    private TextField TXTF_idNumber;
    @FXML
    private Button BTN_signup;
    @FXML
    private Hyperlink HPL_already;
    @FXML
    private ImageView IMAGE_email;
    @FXML
    private ImageView IMAGE_password;
    @FXML
    private ImageView IMAGE_idNumber;
    @FXML
    private VBox VBOX_center;
    @FXML
    private TextField TXTF_user;
    @FXML
    private Pane PANE_iconBG3;
    @FXML
    private ImageView IMAGE_user;
    @FXML
    private Pane PANE_iconBG4;
    @FXML
    private Pane PANE_iconBG5;
    @FXML
    private Pane PANE_iconBG6;
    @FXML
    private ImageView IMAGE_confirm;
    @FXML
    private Pane PANE_iconBG7;
    @FXML
    private Tooltip TOOLTIP_username;
    @FXML
    private Tooltip TOOLTIP_email;
    @FXML
    private Tooltip TOOLTIP_password;
    @FXML
    private Tooltip TOOLTIP_confirm;
    @FXML
    private Tooltip TOOLTIP_idNumber;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void HPL_already(ActionEvent event) throws IOException {
        Parent LogIn = FXMLLoader.load(getClass().getResource("/FXML/Login_UI.fxml"));
        Scene GoLogIn = new Scene(LogIn);
        Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        appStage.setScene(GoLogIn);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
        
    }

    @FXML
    private void BTN_signup(ActionEvent event) throws IOException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance", "root", "");
        } catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        String user = TXTF_user.getText();
        String email = TXTF_email.getText();
        String pass = PASSF_password.getText();
        String cpass = PASSF_confirm.getText();
        String idnum = TXTF_idNumber.getText();

        if("".equals(user) || "".equals(email) || "".equals(pass) || "".equals(cpass) || "".equals(idnum)){
            JOptionPane.showMessageDialog(null, "Please fill up all the fields!");
            return;
        } 
        int y = 0;
        try {
            pst = conn.prepareStatement("SELECT * FROM tbluseraccount");
            rs = pst.executeQuery();

            while (rs.next()) {
                String idnumber = rs.getString("ID_NUM");
                String username = rs.getString("USR_NAME");
                String emailaddress = rs.getString("USR_EADDRESS");
                String password = rs.getString("USR_PASSWORD");

                if (email.equals(emailaddress) || idnum.equals(idnumber)) {
                    JOptionPane.showMessageDialog(null, "This user already exists!");
                    TXTF_idNumber.setText("");
                    TXTF_user.setText("");
                    TXTF_email.setText("");
                    PASSF_password.setText("");
                    PASSF_confirm.setText("");
                    y++;
                    break;
                }
            }
            if (y == 0) {
                if (PASSF_password.getText().equals(cpass)) {
                    try {
                        pst = conn.prepareStatement("INSERT INTO tbluseraccount(ID_NUM,USR_NAME,USR_EADDRESS,USR_PASSWORD) VALUES (?,?,?,?)");
                        pst.setString(1, idnum);
                        pst.setString(2, user);
                        pst.setString(3, email);
                        pst.setString(4, pass);
                        int x = pst.executeUpdate();

                        if (x == 1) {
                            JOptionPane.showMessageDialog(null, "You have succesfully registered!");
                            TXTF_idNumber.setText("");
                            TXTF_user.setText("");
                            TXTF_email.setText("");
                            PASSF_password.setText("");
                            PASSF_confirm.setText("");
                            JOptionPane.showMessageDialog(null, "You will be redirected to the login page!");

                            Parent LogIn = FXMLLoader.load(getClass().getResource("/FXML/Login_UI.fxml"));
                            Scene GoLogIn = new Scene(LogIn);
                            Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                            appStage.setScene(GoLogIn);
                            appStage.setMaximized(false);
                            appStage.setMaximized(true);
                            appStage.show();
                        } else {
                            JOptionPane.showMessageDialog(null, "Register failed!");
                        }
                    } catch (SQLException ex) {
                        java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Password and Confirm Password Does'nt Match!");
                    PASSF_password.setText("");
                    PASSF_confirm.setText("");
                }
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
    }

}
