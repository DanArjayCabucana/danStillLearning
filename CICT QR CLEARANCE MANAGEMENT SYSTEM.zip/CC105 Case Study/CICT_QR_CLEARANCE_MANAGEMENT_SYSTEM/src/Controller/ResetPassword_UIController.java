package Controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

import Encapsulation.EncapsulateValue;
import MainClass.Start;

public class ResetPassword_UIController implements Initializable {
    
    Connection conn;
    PreparedStatement pst;
    ResultSet rs;
    
    EncapsulateValue EV = EncapsulateValue.getInstance();
    
    @FXML
    private BorderPane BDP_background;
    @FXML
    private Pane PANE_container;
    @FXML
    private Text TXT_title;
    @FXML
    private PasswordField PASSF_password;
    @FXML
    private PasswordField PASSF_confirm;
    @FXML
    private Button BTN_confirm;
    @FXML
    private Pane PANE_iconBG1;
    @FXML
    private ImageView IMAGE_password;
    @FXML
    private Pane PANE_iconBG2;
    @FXML
    private ImageView IMAGE_confirm;   
    @FXML
    private Button BTN_back;
    @FXML
    private ImageView IMAGE_back;
        
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //TODO
    }

    @FXML
    private void BTN_confirm(ActionEvent event) throws IOException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/cict_qr_code_clearance","root","");
        }catch (SQLException | ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        String User = EV.getUser();
        String Id = EV.getId();
        String p = PASSF_password.getText();
        String cp = PASSF_confirm.getText();
        
        if(PASSF_password.getText().equals(cp) && !PASSF_password.getText().isEmpty() && !PASSF_confirm.getText().isEmpty()){
            try{
                pst = conn.prepareStatement("UPDATE tbluseraccount SET USR_PASSWORD=? WHERE ID_NUM=? AND USR_EADDRESS=?");
                pst.setString(1, p);
                pst.setString(2, Id);
                pst.setString(3, User);
                int x = pst.executeUpdate();
            
                if(x==1){
                    JOptionPane.showMessageDialog(null, "You have succesfully reset your password!");
                    PASSF_password.setText("");
                    PASSF_confirm.setText("");
                    JOptionPane.showMessageDialog(null, "You will be redirected to the login page!");
                    
                    Parent LogIn = FXMLLoader.load(getClass().getResource("/FXML/Login_UI.fxml"));
                    Scene GoLogIn = new Scene(LogIn);
                    Stage appStage = (Stage) ((Node)event.getSource()).getScene().getWindow();
                    appStage.setScene(GoLogIn);
                    appStage.setMaximized(false);
                    appStage.setMaximized(true);
                    appStage.show();
                }else{
                    JOptionPane.showMessageDialog(null, "Reset Password Failed!");
                }
            } catch (SQLException ex) {
                java.util.logging.Logger.getLogger(Start.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } 
        }else{
            JOptionPane.showMessageDialog(null, "Password and Confirm Password Does'nt Match!");
            PASSF_password.setText("");
            PASSF_confirm.setText("");
        }
        
    }    

    @FXML
    private void BTN_back(ActionEvent event) throws IOException {
        Parent Back = FXMLLoader.load(getClass().getResource("/FXML/ForgotPassword_UI.fxml"));
        Scene GoBack = new Scene(Back);
        Stage appStage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        appStage.setScene(GoBack);
        appStage.setMaximized(false);
        appStage.setMaximized(true);
        appStage.show();
        
    }
    
}
